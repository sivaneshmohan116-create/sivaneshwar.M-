/* ============================================================
   Health Prediction System
   Modules: 1 Authentication | 2 Symptom Input | 3 Disease Prediction
            4 Health Report | 5 Doctor Recommendation | 6 Database
   Data is stored in the browser's localStorage (demo database).
   ============================================================ */

const $ = (id) => document.getElementById(id);
const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* ---------------- Module 6: Database (localStorage) ---------------- */
const DB = {
  get(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch { return fallback; }
  },
  set(key, value) { localStorage.setItem(key, JSON.stringify(value)); },
  users() { return this.get("hp_users", []); },
  records() { return this.get("hp_records", []); },
  session() { return this.get("hp_session", null); },
};

/* ---------------- Knowledge base ---------------- */
const SYMPTOMS = {
  fever: "Fever", cough: "Cough", sore_throat: "Sore throat", runny_nose: "Runny nose",
  sneezing: "Sneezing", headache: "Headache", body_ache: "Body ache", fatigue: "Fatigue",
  chills: "Chills", nausea: "Nausea", vomiting: "Vomiting", diarrhea: "Diarrhoea",
  abdominal_pain: "Abdominal pain", rash: "Skin rash", joint_pain: "Joint pain",
  loss_smell: "Loss of smell or taste", breathless: "Shortness of breath", chest_pain: "Chest pain",
  wheezing: "Wheezing", frequent_urination: "Frequent urination", excessive_thirst: "Excessive thirst",
  blurred_vision: "Blurred vision", dizziness: "Dizziness", light_sensitivity: "Sensitivity to light",
  itchy_eyes: "Itchy eyes", yellow_skin: "Yellow skin or eyes", confusion: "Confusion",
};

const EMERGENCY_SYMPTOMS = ["chest_pain", "breathless", "confusion"];

// weights: 3 = key symptom, 2 = common, 1 = occasional
const DISEASES = [
  { name: "Common cold", urgency: 1, doctor: "General Physician",
    w: { runny_nose: 3, sneezing: 3, sore_throat: 2, cough: 2, headache: 1, fatigue: 1, fever: 1 },
    causes: ["Rhinovirus and other viral infections", "Close contact with infected people"],
    advice: ["Rest and drink warm fluids", "Gargle with warm salt water", "Take paracetamol for fever or pain if needed"] },
  { name: "Influenza (flu)", urgency: 2, doctor: "General Physician",
    w: { fever: 3, body_ache: 3, chills: 2, fatigue: 2, cough: 2, headache: 2, sore_throat: 1 },
    causes: ["Influenza virus spread by droplets", "Seasonal outbreaks"],
    advice: ["Rest and stay hydrated", "Avoid contact with others to prevent spread", "See a doctor if fever lasts more than 3 days"] },
  { name: "COVID-19", urgency: 2, doctor: "General Physician / Pulmonologist",
    w: { fever: 2, cough: 3, loss_smell: 3, fatigue: 2, breathless: 2, body_ache: 1, sore_throat: 1, headache: 1 },
    causes: ["SARS-CoV-2 virus", "Contact with an infected person"],
    advice: ["Take a COVID-19 test", "Isolate and wear a mask", "Monitor oxygen level and seek care if breathing worsens"] },
  { name: "Dengue", urgency: 3, doctor: "General Physician",
    w: { fever: 3, headache: 2, joint_pain: 3, body_ache: 2, rash: 2, nausea: 1, vomiting: 1, fatigue: 1 },
    causes: ["Bite of an infected Aedes mosquito", "Stagnant water around the home"],
    advice: ["Get a dengue NS1 / platelet count test", "Drink plenty of fluids", "Avoid aspirin and ibuprofen"] },
  { name: "Malaria", urgency: 3, doctor: "General Physician",
    w: { fever: 3, chills: 3, headache: 1, vomiting: 1, nausea: 1, body_ache: 1, fatigue: 1 },
    causes: ["Bite of an infected Anopheles mosquito", "Travel to or living in endemic areas"],
    advice: ["Get a blood smear or rapid malaria test", "Use mosquito nets and repellents", "Start treatment only as prescribed"] },
  { name: "Typhoid fever", urgency: 3, doctor: "General Physician / Gastroenterologist",
    w: { fever: 3, abdominal_pain: 2, headache: 2, fatigue: 1, diarrhea: 1, nausea: 1 },
    causes: ["Salmonella Typhi from contaminated food or water", "Poor sanitation"],
    advice: ["Get a blood culture or Widal test", "Drink only boiled or filtered water", "Complete the full antibiotic course"] },
  { name: "Gastroenteritis", urgency: 2, doctor: "Gastroenterologist",
    w: { diarrhea: 3, vomiting: 3, nausea: 2, abdominal_pain: 2, fever: 1 },
    causes: ["Viral or bacterial infection", "Contaminated food or water"],
    advice: ["Drink oral rehydration solution", "Eat light food such as rice and banana", "See a doctor if you cannot keep fluids down"] },
  { name: "Migraine", urgency: 1, doctor: "Neurologist",
    w: { headache: 3, light_sensitivity: 3, nausea: 2, vomiting: 1, dizziness: 1 },
    causes: ["Stress, lack of sleep or skipped meals", "Hormonal changes and certain food triggers"],
    advice: ["Rest in a dark, quiet room", "Keep a trigger diary", "Consult a neurologist if attacks are frequent"] },
  { name: "Type 2 diabetes", urgency: 2, doctor: "Endocrinologist",
    w: { frequent_urination: 3, excessive_thirst: 3, blurred_vision: 2, fatigue: 2 },
    causes: ["Insulin resistance linked to obesity and inactivity", "Family history of diabetes"],
    advice: ["Get fasting blood sugar and HbA1c tests", "Reduce sugar and refined carbohydrates", "Walk at least 30 minutes daily"] },
  { name: "Asthma", urgency: 2, doctor: "Pulmonologist",
    w: { wheezing: 3, breathless: 3, cough: 2, chest_pain: 1 },
    causes: ["Allergens, dust and smoke", "Cold air, exercise or respiratory infections"],
    advice: ["Avoid known triggers", "Keep a prescribed inhaler nearby", "Get a lung function (spirometry) test"] },
  { name: "Pneumonia", urgency: 3, doctor: "Pulmonologist",
    w: { fever: 2, cough: 3, breathless: 3, chest_pain: 2, chills: 1, fatigue: 1 },
    causes: ["Bacterial or viral lung infection", "Weak immunity, smoking or recent flu"],
    advice: ["Get a chest X-ray", "Do not delay medical care", "Rest and drink fluids"] },
  { name: "Allergic rhinitis", urgency: 1, doctor: "ENT Specialist / Allergist",
    w: { sneezing: 3, itchy_eyes: 3, runny_nose: 2, rash: 1 },
    causes: ["Pollen, dust mites or pet dander", "Seasonal changes"],
    advice: ["Avoid dust and allergens", "Antihistamines may help (ask a pharmacist)", "Keep windows closed during high pollen days"] },
  { name: "Hepatitis / Jaundice", urgency: 3, doctor: "Gastroenterologist",
    w: { yellow_skin: 3, fatigue: 2, abdominal_pain: 2, nausea: 1, vomiting: 1 },
    causes: ["Hepatitis A or E from contaminated food or water", "Liver disease or excess alcohol"],
    advice: ["Get liver function tests", "Avoid alcohol and oily food", "Consult a doctor promptly"] },
];

const URGENCY = {
  1: { label: "Low", cls: "low", text: "Consult a doctor if symptoms last more than a week." },
  2: { label: "Moderate", cls: "mid", text: "Consult a doctor within 2 to 3 days." },
  3: { label: "High", cls: "high", text: "Consult a doctor within 24 hours." },
  4: { label: "Emergency", cls: "high", text: "Seek emergency medical care immediately." },
};

/* ---------------- Module 1: Authentication ---------------- */
async function hash(text) {
  try {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch {
    // fallback for browsers without crypto.subtle
    let h = 5381;
    for (const c of text) h = ((h << 5) + h + c.charCodeAt(0)) | 0;
    return String(h);
  }
}

function showError(id, msg) {
  $(id).textContent = msg;
  $(id).hidden = !msg;
}

document.querySelectorAll("[data-auth]").forEach((btn) =>
  btn.addEventListener("click", () => {
    const login = btn.dataset.auth === "login";
    $("loginForm").hidden = !login;
    $("registerForm").hidden = login;
    document.querySelectorAll("[data-auth]").forEach((b) => b.classList.toggle("active", b === btn));
  })
);

$("registerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = $("regName").value.trim();
  const email = $("regEmail").value.trim().toLowerCase();
  const pass = $("regPass").value;
  if (!name || !/^\S+@\S+\.\S+$/.test(email)) return showError("regError", "Enter your name and a valid email address.");
  if (pass.length < 6) return showError("regError", "Password must have at least 6 characters.");
  const users = DB.users();
  if (users.some((u) => u.email === email)) return showError("regError", "This email is already registered. Log in instead.");
  users.push({ name, email, role: $("regRole").value, pass: await hash(pass) });
  DB.set("hp_users", users);
  DB.set("hp_session", email);
  showError("regError", "");
  e.target.reset();
  startApp();
});

$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = $("loginEmail").value.trim().toLowerCase();
  const user = DB.users().find((u) => u.email === email);
  if (!user || user.pass !== (await hash($("loginPass").value)))
    return showError("loginError", "Incorrect email or password.");
  DB.set("hp_session", email);
  showError("loginError", "");
  e.target.reset();
  startApp();
});

$("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("hp_session");
  $("appView").hidden = true;
  $("userBar").hidden = true;
  $("authView").hidden = false;
});

function currentUser() {
  const email = DB.session();
  return DB.users().find((u) => u.email === email) || null;
}

function startApp() {
  const user = currentUser();
  if (!user) return;
  $("authView").hidden = true;
  $("appView").hidden = false;
  $("userBar").hidden = false;
  $("userName").textContent = `${user.name} (${user.role})`;
  $("reportBody").hidden = true;
  $("reportEmpty").hidden = false;
  switchView("checkView");
}

/* ---------------- Navigation ---------------- */
function switchView(id) {
  document.querySelectorAll(".view").forEach((v) => (v.hidden = v.id !== id));
  document.querySelectorAll("[data-view]").forEach((b) => b.classList.toggle("active", b.dataset.view === id));
  if (id === "historyView") renderHistory();
}
document.querySelectorAll("[data-view]").forEach((b) => b.addEventListener("click", () => switchView(b.dataset.view)));

/* ---------------- Module 2: Symptom Input ---------------- */
$("symptomGrid").innerHTML = Object.entries(SYMPTOMS)
  .map(([id, label]) => `<label class="chk"><input type="checkbox" value="${id}"> ${label}</label>`)
  .join("");

$("clearBtn").addEventListener("click", () => {
  showError("symError", "");
  document.querySelectorAll(".invalid").forEach((el) => el.classList.remove("invalid"));
});

$("symptomForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const age = +$("age").value, days = +$("days").value, gender = $("gender").value;
  const selected = [...document.querySelectorAll("#symptomGrid input:checked")].map((c) => c.value);

  const badAge = !(age >= 1 && age <= 110), badDays = !(days >= 1 && days <= 365);
  $("age").classList.toggle("invalid", badAge);
  $("days").classList.toggle("invalid", badDays);
  $("gender").classList.toggle("invalid", !gender);

  if (badAge || badDays || !gender) return showError("symError", "Enter a valid age, gender and number of days.");
  if (selected.length === 0) return showError("symError", "Select at least one symptom.");
  showError("symError", "");

  const user = currentUser();
  const predictions = predict(selected);
  const record = {
    id: Date.now(),
    email: user.email,
    patient: user.name,
    date: new Date().toISOString(),
    age, gender, days, symptoms: selected,
    predictions: predictions.map((p) => ({ name: p.name, conf: p.conf })),
    top: predictions[0] ? predictions[0].name : "No match",
    emergency: isEmergency(selected, predictions, age),
  };
  const all = DB.records();
  all.push(record);
  DB.set("hp_records", all);

  renderReport(record);
  switchView("reportView");
});

/* ---------------- Module 3: Disease Prediction ---------------- */
// Confidence = harmonic mean of
//   recall    : weight of the disease's symptoms the patient has / total weight of that disease
//   precision : how many of the patient's symptoms are explained by the disease
function predict(selected) {
  const results = DISEASES.map((d) => {
    const total = Object.values(d.w).reduce((a, b) => a + b, 0);
    const matched = selected.filter((s) => d.w[s]);
    const matchedW = matched.reduce((sum, s) => sum + d.w[s], 0);
    if (matched.length === 0) return null;
    const recall = matchedW / total;
    const precision = matched.length / selected.length;
    const conf = Math.round(((2 * recall * precision) / (recall + precision)) * 100);
    return { ...d, conf, matched };
  }).filter(Boolean);
  results.sort((a, b) => b.conf - a.conf);
  return results.slice(0, 3);
}

function isEmergency(selected, predictions, age) {
  if (selected.some((s) => EMERGENCY_SYMPTOMS.includes(s))) return true;
  const top = predictions[0];
  return !!top && top.urgency === 3 && top.conf >= 70 && (age >= 60 || age <= 5);
}

/* ---------------- Modules 4 and 5: Report and Doctor Recommendation ---------------- */
function renderReport(rec) {
  const preds = rec.predictions.map((p) => DISEASES.find((d) => d.name === p.name) && { ...DISEASES.find((d) => d.name === p.name), conf: p.conf }).filter(Boolean);
  const top = preds[0];
  const level = rec.emergency ? 4 : top ? top.urgency : 1;
  const u = URGENCY[level];

  const riskFactors = [];
  if (rec.age >= 60) riskFactors.push("Age 60 or above increases the risk of complications.");
  if (rec.age <= 5) riskFactors.push("Young children can become seriously ill quickly.");
  if (rec.days > 7) riskFactors.push(`Symptoms have lasted ${rec.days} days, which is longer than most mild illnesses.`);
  if (rec.symptoms.length >= 6) riskFactors.push("Many symptoms are present together.");
  if (riskFactors.length === 0) riskFactors.push("No additional risk factors found from the details given.");

  let html = "";
  if (rec.emergency)
    html += `<div class="alert" role="alert">Emergency alert: your symptoms may need urgent care. Call your local emergency number or go to the nearest hospital now.</div>`;

  html += `<h2>Health report</h2>
    <div class="meta">
      <span><b>Patient:</b> ${esc(rec.patient)}</span>
      <span><b>Age / gender:</b> ${rec.age}, ${esc(rec.gender)}</span>
      <span><b>Duration:</b> ${rec.days} day(s)</span>
      <span><b>Date:</b> ${new Date(rec.date).toLocaleString()}</span>
    </div>
    <p><b>Symptoms:</b> ${rec.symptoms.map((s) => esc(SYMPTOMS[s])).join(", ")}</p>`;

  html += `<h3>Possible diseases</h3>`;
  if (!top) {
    html += `<p>No matching disease found for these symptoms. Please consult a doctor.</p>`;
  } else {
    html += preds.map((p) => `
      <div class="pred">
        <div class="pred-head"><span>${esc(p.name)}</span><span>${p.conf}% confidence</span></div>
        <div class="bar"><div data-w="${p.conf}"></div></div>
      </div>`).join("");

    html += `<div class="two">
      <div><h3>Possible causes of ${esc(top.name)}</h3><ul>${top.causes.map((c) => `<li>${esc(c)}</li>`).join("")}</ul></div>
      <div><h3>Risk factors</h3><ul>${riskFactors.map((r) => `<li>${esc(r)}</li>`).join("")}</ul></div>
    </div>
    <h3>Health recommendations</h3>
    <ul>${top.advice.map((a) => `<li>${esc(a)}</li>`).join("")}</ul>`;
  }

  html += `<h3>Doctor recommendation</h3>
    <p><b>Specialist:</b> ${top ? esc(top.doctor) : "General Physician"}</p>
    <p><b>Consultation urgency:</b> <span class="pill ${u.cls}">${u.label}</span> ${u.text}</p>
    <p class="note">Confidence shows how closely your symptoms match each disease in the model. It is not a clinical probability and this report is not a diagnosis.</p>
    <div class="actions"><button type="button" id="printBtn">Print report</button></div>`;

  $("reportEmpty").hidden = true;
  $("reportBody").hidden = false;
  $("reportBody").innerHTML = html;
  $("printBtn").addEventListener("click", () => window.print());
  requestAnimationFrame(() =>
    document.querySelectorAll("#reportBody .bar > div").forEach((b) => (b.style.width = b.dataset.w + "%"))
  );
}

/* ---------------- Module 6: Prediction history ---------------- */
function renderHistory() {
  const user = currentUser();
  const isDoctor = user.role === "doctor";
  const rows = DB.records()
    .filter((r) => isDoctor || r.email === user.email)
    .sort((a, b) => b.id - a.id);

  $("historyTitle").textContent = isDoctor ? "All patient records" : "Your prediction history";

  if (rows.length === 0) {
    $("historyBody").innerHTML = `<div class="empty"><p>No records saved yet.</p></div>`;
    return;
  }

  $("historyBody").innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Date</th>${isDoctor ? "<th>Patient</th>" : ""}<th>Top prediction</th><th>Confidence</th><th>Symptoms</th><th></th></tr></thead>
    <tbody>${rows.map((r) => `<tr>
      <td>${new Date(r.date).toLocaleDateString()}</td>
      ${isDoctor ? `<td>${esc(r.patient)}</td>` : ""}
      <td>${esc(r.top)}${r.emergency ? ' <span class="pill high">Emergency</span>' : ""}</td>
      <td>${r.predictions[0] ? r.predictions[0].conf + "%" : "-"}</td>
      <td>${r.symptoms.map((s) => esc(SYMPTOMS[s])).join(", ")}</td>
      <td><button type="button" class="ghost" data-open="${r.id}">View</button></td>
    </tr>`).join("")}</tbody></table></div>
    <div class="actions"><button type="button" class="ghost" id="clearHistory">Delete my records</button></div>`;

  document.querySelectorAll("[data-open]").forEach((b) =>
    b.addEventListener("click", () => {
      renderReport(DB.records().find((r) => r.id === +b.dataset.open));
      switchView("reportView");
    })
  );
  $("clearHistory").addEventListener("click", () => {
    if (!confirm("Delete all of your saved records?")) return;
    DB.set("hp_records", DB.records().filter((r) => r.email !== user.email));
    renderHistory();
  });
}

/* ---------------- Init ---------------- */
if (currentUser()) startApp();
